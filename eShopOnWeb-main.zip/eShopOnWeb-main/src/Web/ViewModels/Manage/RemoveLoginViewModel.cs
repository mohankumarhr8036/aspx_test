﻿namespace Microsoft.eShopWeb.Web.ViewModels.Manage;

public class RemoveLoginViewModel
{
    public string LoginProvider { get; set; }
    public string ProviderKey { get; set; }
}
